Sir.HUD
=======

I made this HUD as a Spy Main and so a lot of the things that are important to me are what I made this HUD around. 

Enemy health and enemy Übercharge percentage are easily visible because that shit is important.
Health and ammo are easy to see, cloak and knife meters are central, but thin so that they don’t obscure too much of the screen. 

Damage numbers are small but clear.

MVM is not well supported, but it’s usable. The Vaccinator HUD is not done at all and I don’t know if I will get around to it in the near future. Apologies to Vaccinator lovers.

## Screenshots

The [Official Page](http://sir.grey.tf/hud) contains screenshots.

## Customisability

I'm afraid that this HUD is not made for customisability. You're welcome to mess around with it, but if you break it then I'm afraid I won't be providing support. 

## Broken Parts

If you find something broken, or if a new HUD item is added, I'm afraid that updates will come slowly and only be there if I decide to add it for myself. If someone knows the code to add support for a new HUD element then you are welcome to suggest the code. Other than that, I'm afraid no support will be given.